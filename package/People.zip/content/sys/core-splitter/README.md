core-splitter
=============

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-splitter) for more information.
