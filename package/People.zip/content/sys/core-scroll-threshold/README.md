core-scroll-threshold
=========

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-scroll-threshold) for more information.
