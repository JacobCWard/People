core-localstorage
=================

See the [component landing page](http://polymer-project.org/docs/elements/core-elements.html#core-localstorage) for more information.
