core-pages
==========

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-pages) for more information.
